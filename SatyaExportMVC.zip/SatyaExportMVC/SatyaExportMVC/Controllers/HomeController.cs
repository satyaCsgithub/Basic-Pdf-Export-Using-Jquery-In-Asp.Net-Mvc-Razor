﻿using System;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.tool.xml;
using iTextSharp.text.html.simpleparser;
using System.Web.UI.WebControls;
using System.Web.UI;


namespace ImageuploadingDemo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult FileUpload()
        {
            StudentEntities db = new StudentEntities();
            tblExport student = new tblExport();
            student.FirstName = Request.Form["firstname"];
            student.LastName = Request.Form["lastname"];
            db.tblExports.Add(student);
            db.SaveChanges();
            return RedirectToAction("../home/DisplayImage/");
        }

        public ActionResult DisplayImage()
        {
            return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public FileResult Export(string GridHtml)
        {
            using (MemoryStream stream = new System.IO.MemoryStream())
            {
                StringReader sr = new StringReader(GridHtml);
                Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, stream);
                pdfDoc.Open();
                XMLWorkerHelper.GetInstance().ParseXHtml(writer, pdfDoc, sr);
                pdfDoc.Close();
                return File(stream.ToArray(), "application/pdf", "StudentDetails.pdf");
            }
        }
    }
}
